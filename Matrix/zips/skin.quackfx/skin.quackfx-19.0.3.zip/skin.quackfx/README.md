# skin.quackfx

## KODI File Manager Source: https://mucky-duck.github.io/QuackFX

### QuackFX is a skin/theme for KODI.

**The Leia version is based on the Titan Skin 
and was my first attempt at editing the xml files. 
BIG THANKS to @marcelveldt for his work on the 
original code for the Titan skin & addons.
https://github.com/marcelveldt. 
Also Thanks to @cartmondos for his work on updating 
the Titan Skin to KODI 18 Leia.
https://github.com/cartmandos/skin.titan.bingie.mode.**


**The Matrix version is based on the Aura Skin 
and will be my second attempt with playing around 
with xml code. BIG THANKS to @Jurialmunkey for his work on the 
original code for the Aura skin & addons.
https://github.com/jurialmunkey/skin.aura. 
Also Thanks to @skyfsza & @SerpentDrago and anyone 
else that helped create the AuraMod.
https://github.com/skyfsza/skin.auramod version 18 Leia.
https://github.com/SerpentDrago/skin.auramod version 19 Matrix.**


