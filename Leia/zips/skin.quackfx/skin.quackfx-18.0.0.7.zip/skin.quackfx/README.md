# skin.quackfx

QuackFX is a skin/theme for KODI 18 Leia based on the Titan Skin 
this skin will be my first ive done so will be a work in progress.  

BIG THANKS to @marcelveldt for his work on the original code for the Titan skin & addons.
https://github.com/marcelveldt

Also Thanks to @cartmondos for his work on updating the Titan Skin to KODI 18 Leia.
https://github.com/cartmandos/skin.titan.bingie.mode