# script.skin.helper.service

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/d253881b0e6a45a68a82dec8ee275d8f)](https://www.codacy.com/app/m-vanderveldt/script-skin-helper-service?utm_source=github.com&utm_medium=referral&utm_content=marcelveldt/script.skin.helper.service&utm_campaign=badger)

a helper service for Kodi skins

________________________________________________________________________________________________________


All documentation for this addon can be found in the online wiki:

https://github.com/marcelveldt/script.skin.helper.service/wiki


